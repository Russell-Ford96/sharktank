-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: localhost    Database: budget
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `savings` decimal(20,0) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'\'test@example.com\'','$2a$10$TU89dkxSNCpe97RsiNml5OyWlzg1dj9FFP11FcVWSLse.MjCB16W2','\'Russell\'','\'Ford\'',NULL),(9,'\'test2@example.com\'','$2a$10$4t/17t1rS5h8/E/dMRUR/Opp96FnBIJGpLSdaqqPpqlDOC0VqErI6','\'Russell\'','\'Ford\'',NULL),(10,'\'test3@example.com\'','$2a$10$o7UCmw0a.8ymLdsE7KLEjOXKr2rMPyAz9UrMWzfTZ9AMtzmTleUjq','\'adsf\'','\'asdf\'',NULL),(11,'\'test8@example.com\'','$2a$10$fMz9yyfkB1wuQxfHtgJZq./Pe.3wo907QTqyz/qnf88nHVYkkeP3i','\'test\'','\'test\'',NULL),(12,'\'hello@world.com\'','$2a$10$Byg8rBcz/ALz1ePEDQUF0OPUJpPho7G2/wP3mIyc3vEAsi9OLcUuC','\'hello\'','\'world\'',NULL),(13,'\'test123@example.com\'','$2a$10$5En5l.KtnVvc8r/vk.f9KeJq/oTVZ8FLkLaeZZVto7Kw3fy5OjHDS','\'hello\'','\'world\'',NULL),(14,'\'test@test.com\'','$2a$10$JkXE3Icn7v1R86UNKlA2.Oxh7R7/sW1/uZQO2S6kk/6SRQDQjHcnm','\'test\'','\'test\'',NULL),(15,'testm@example.com','$2a$10$B/zY.ykPpVr5CMm/JImacOG3libw3Dp.O.PPOGhFvfPfTYJM/akHO','hello','world',NULL),(16,'break@test.com','$2a$10$CB0jUCxF3.Bo3Z4245pcMuCMTzjdC0W1wfhp/klhExpvV3Zs1SAAe','test','did',NULL),(17,'break@break.com','$2a$10$/03cxzQYagjZ5SoxH03OVe/qAbTYQXC4suBFIWcyfMh025uLORjTm','test','test',NULL),(18,'\'testt@example.com\'','$2a$10$VyB7nFi0OmtuMuPUlomF9udeo4hayajnunS4fp1/q2c7Z3ySFFsBG','\'Russell\'','\'Ford\'',NULL),(19,'\'testies@example.com\'','$2a$10$S4nG0awS/U/lz7PC5hpkNOJAIU.FcKFmR6xywYanGAfNBjq7V.fdK','\'Russell\'','\'Ford\'',NULL);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-08 12:27:34
